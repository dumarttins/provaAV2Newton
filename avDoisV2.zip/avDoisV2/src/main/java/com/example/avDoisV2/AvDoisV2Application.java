package com.example.avDoisV2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvDoisV2Application {

	public static void main(String[] args) {
		SpringApplication.run(AvDoisV2Application.class, args);
	}

}
